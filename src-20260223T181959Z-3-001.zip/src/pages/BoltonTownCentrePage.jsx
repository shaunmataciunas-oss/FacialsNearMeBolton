import React from 'react';
import LocationPageLayout from '@/components/LocationPageLayout';
export default function BoltonTownCentrePage() { return <LocationPageLayout locationId="bolton-town-centre" />; }
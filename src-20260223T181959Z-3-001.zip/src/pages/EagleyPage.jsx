import React from 'react';
import LocationPageLayout from '@/components/LocationPageLayout';
export default function EagleyPage() { return <LocationPageLayout locationId="eagley" />; }
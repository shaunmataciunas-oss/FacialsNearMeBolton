import React from 'react';
import LocationPageLayout from '@/components/LocationPageLayout';
export default function GreatLeverPage() { return <LocationPageLayout locationId="great-lever" />; }
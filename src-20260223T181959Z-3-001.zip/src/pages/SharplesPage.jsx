import React from 'react';
import LocationPageLayout from '@/components/LocationPageLayout';
export default function SharplesPage() { return <LocationPageLayout locationId="sharples" />; }
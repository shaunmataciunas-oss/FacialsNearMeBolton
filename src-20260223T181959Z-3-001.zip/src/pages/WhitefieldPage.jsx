import React from 'react';
import LocationPageLayout from '@/components/LocationPageLayout';
export default function WhitefieldPage() { return <LocationPageLayout locationId="whitefield" />; }
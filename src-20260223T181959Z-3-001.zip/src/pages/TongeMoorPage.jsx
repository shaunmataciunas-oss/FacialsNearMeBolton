import React from 'react';
import LocationPageLayout from '@/components/LocationPageLayout';
export default function TongeMoorPage() { return <LocationPageLayout locationId="tonge-moor" />; }
import React from 'react';
import LocationPageLayout from '@/components/LocationPageLayout';
export default function HorwichPage() { return <LocationPageLayout locationId="horwich" />; }
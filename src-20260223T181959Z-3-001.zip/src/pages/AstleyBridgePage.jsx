import React from 'react';
import LocationPageLayout from '@/components/LocationPageLayout';
export default function AstleyBridgePage() { return <LocationPageLayout locationId="astley-bridge" />; }
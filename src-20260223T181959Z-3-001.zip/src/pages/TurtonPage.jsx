import React from 'react';
import LocationPageLayout from '@/components/LocationPageLayout';
export default function TurtonPage() { return <LocationPageLayout locationId="turton" />; }